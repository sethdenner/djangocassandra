#!/bin/bash

python manage.py test provider oauth2 --traceback --failfast


